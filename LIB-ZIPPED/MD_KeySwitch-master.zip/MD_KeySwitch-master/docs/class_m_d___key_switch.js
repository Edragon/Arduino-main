var class_m_d___key_switch =
[
    [ "keyResult_t", "class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74a", [
      [ "KS_NULL", "class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa74d054189ce180aaa6e0200de8adc3e4", null ],
      [ "KS_PRESS", "class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aae082ecde5fbf3366aa0107b6526a2530", null ],
      [ "KS_DPRESS", "class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa506572ca2664ccfd0fabd24e5e6348a5", null ],
      [ "KS_LONGPRESS", "class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa94293b5a79ec364f9ec5813ee57fb733", null ],
      [ "KS_RPTPRESS", "class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa4b06e20a12208b175ac34a59982d4292", null ]
    ] ],
    [ "state_t", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7", [
      [ "S_IDLE", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7a2795bf9114a6f3efc0679f3e31afc80f", null ],
      [ "S_DEBOUNCE1", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7af1ea0f921afdc749f9c8e4e2c61e6164", null ],
      [ "S_DEBOUNCE2", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7a56028b791fe7c46d5a179d858ddf3f42", null ],
      [ "S_PRESS", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7aea32b69cffa32460bf8c272f0487aff1", null ],
      [ "S_DPRESS", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7af3e0c9869a4048068755fb5d50513ddd", null ],
      [ "S_LPRESS", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7afafa16b2271934e4dba08fb50e4a5358", null ],
      [ "S_REPEAT", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7a6ac0e566bc2a3dcacfbc6e1382afd2a7", null ],
      [ "S_WAIT", "class_m_d___key_switch.html#a1dab2407812335266e7594484f700be7aae9a364cb385a5b246990fa72af83132", null ]
    ] ],
    [ "MD_KeySwitch", "class_m_d___key_switch.html#a3d571ba8f5f94ce9f80b3a222e1250fa", null ],
    [ "~MD_KeySwitch", "class_m_d___key_switch.html#a7ddbaa67b30aff780b373c38b6699e91", null ],
    [ "begin", "class_m_d___key_switch.html#aa60ffd87e573c59e2016c56adf18fddb", null ],
    [ "enableDoublePress", "class_m_d___key_switch.html#a40c7424fa12cddc94e739857de974c18", null ],
    [ "enableLongPress", "class_m_d___key_switch.html#abdcf34e09bd627a78e12d09d07148004", null ],
    [ "enableRepeat", "class_m_d___key_switch.html#a1c067ca6928b39a39a96e1ce69bab17c", null ],
    [ "enableRepeatResult", "class_m_d___key_switch.html#a6480dd39f64b2f15cf2d45905bf9577c", null ],
    [ "read", "class_m_d___key_switch.html#a5660f8fcb19356b09e2607ef2184734a", null ],
    [ "setDebounceTime", "class_m_d___key_switch.html#a29aab93c85781e9bd1eea2be1498390f", null ],
    [ "setDoublePressTime", "class_m_d___key_switch.html#abfde3ea81f22d0ac8dc7967f8d895946", null ],
    [ "setLongPressTime", "class_m_d___key_switch.html#a394f31fe359f7289a10b326294b14997", null ],
    [ "setRepeatTime", "class_m_d___key_switch.html#acd76ee715b419be88d980eeab17b04c7", null ],
    [ "_enableFlags", "class_m_d___key_switch.html#adf6031b6fbfa53e93bbf3b15aedeb2db", null ],
    [ "_onState", "class_m_d___key_switch.html#a66d8cca12a4d3a68e1525c593e2a9fcd", null ],
    [ "_pin", "class_m_d___key_switch.html#a72db29c1f1beddc1d9bb3a3136734602", null ],
    [ "_state", "class_m_d___key_switch.html#a56a689cb4a9c5bd7cdfeaddfcf109983", null ],
    [ "_timeActive", "class_m_d___key_switch.html#a15cfc6a0e027dff3f7c271b68d9bae94", null ],
    [ "_timeDebounce", "class_m_d___key_switch.html#a86b2a576db6ba43a08a7a43e4827e6a1", null ],
    [ "_timeDoublePress", "class_m_d___key_switch.html#af445414de0645802cdc56c685d826a5d", null ],
    [ "_timeLongPress", "class_m_d___key_switch.html#a7301b7989214cb4b30b5942019e9e2fe", null ],
    [ "_timeRepeat", "class_m_d___key_switch.html#a624e37b712e5225d61c11c9a77182247", null ]
];
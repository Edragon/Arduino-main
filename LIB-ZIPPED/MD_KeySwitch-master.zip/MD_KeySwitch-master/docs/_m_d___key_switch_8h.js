var _m_d___key_switch_8h =
[
    [ "MD_KeySwitch", "class_m_d___key_switch.html", "class_m_d___key_switch" ],
    [ "DPRESS_ENABLE", "_m_d___key_switch_8h.html#a71075720e1391402294a8128b87c0299", null ],
    [ "KEY_ACTIVE_STATE", "_m_d___key_switch_8h.html#a31b7db8ca6c72f2c2d1f35676ed7bf1c", null ],
    [ "KEY_DEBOUNCE_TIME", "_m_d___key_switch_8h.html#a96040ac84b114c016c2fe3d517573140", null ],
    [ "KEY_DPRESS_TIME", "_m_d___key_switch_8h.html#aae76c0b46684910532977ccf29720536", null ],
    [ "KEY_LONGPRESS_TIME", "_m_d___key_switch_8h.html#ad04c46920a8921db4b689830ae664082", null ],
    [ "KEY_REPEAT_TIME", "_m_d___key_switch_8h.html#a27b2004a2239fff75146367890c36b6d", null ],
    [ "LONGPRESS_ENABLE", "_m_d___key_switch_8h.html#ae624d1696ade653ff7302c5d6a8055e0", null ],
    [ "REPEAT_ENABLE", "_m_d___key_switch_8h.html#a30909fe7f296d7a592876e8f23673801", null ],
    [ "REPEAT_RESULT_ENABLE", "_m_d___key_switch_8h.html#ae64d8ab4bff3ff8fe3474b9e722c6543", null ]
];
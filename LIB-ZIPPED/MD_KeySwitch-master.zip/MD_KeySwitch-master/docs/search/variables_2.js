var searchData=
[
  ['key_5factive_5fstate',['KEY_ACTIVE_STATE',['../_m_d___key_switch_8h.html#a31b7db8ca6c72f2c2d1f35676ed7bf1c',1,'MD_KeySwitch.h']]],
  ['key_5fdebounce_5ftime',['KEY_DEBOUNCE_TIME',['../_m_d___key_switch_8h.html#a96040ac84b114c016c2fe3d517573140',1,'MD_KeySwitch.h']]],
  ['key_5fdpress_5ftime',['KEY_DPRESS_TIME',['../_m_d___key_switch_8h.html#aae76c0b46684910532977ccf29720536',1,'MD_KeySwitch.h']]],
  ['key_5flongpress_5ftime',['KEY_LONGPRESS_TIME',['../_m_d___key_switch_8h.html#ad04c46920a8921db4b689830ae664082',1,'MD_KeySwitch.h']]],
  ['key_5frepeat_5ftime',['KEY_REPEAT_TIME',['../_m_d___key_switch_8h.html#a27b2004a2239fff75146367890c36b6d',1,'MD_KeySwitch.h']]]
];

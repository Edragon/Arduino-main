var searchData=
[
  ['setdebouncetime',['setDebounceTime',['../class_m_d___key_switch.html#a29aab93c85781e9bd1eea2be1498390f',1,'MD_KeySwitch']]],
  ['setdoublepresstime',['setDoublePressTime',['../class_m_d___key_switch.html#abfde3ea81f22d0ac8dc7967f8d895946',1,'MD_KeySwitch']]],
  ['setlongpresstime',['setLongPressTime',['../class_m_d___key_switch.html#a394f31fe359f7289a10b326294b14997',1,'MD_KeySwitch']]],
  ['setrepeattime',['setRepeatTime',['../class_m_d___key_switch.html#acd76ee715b419be88d980eeab17b04c7',1,'MD_KeySwitch']]]
];

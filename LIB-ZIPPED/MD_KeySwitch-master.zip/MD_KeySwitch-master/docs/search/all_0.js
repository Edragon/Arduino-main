var searchData=
[
  ['_5fenableflags',['_enableFlags',['../class_m_d___key_switch.html#adf6031b6fbfa53e93bbf3b15aedeb2db',1,'MD_KeySwitch']]],
  ['_5fonstate',['_onState',['../class_m_d___key_switch.html#a66d8cca12a4d3a68e1525c593e2a9fcd',1,'MD_KeySwitch']]],
  ['_5fpin',['_pin',['../class_m_d___key_switch.html#a72db29c1f1beddc1d9bb3a3136734602',1,'MD_KeySwitch']]],
  ['_5fstate',['_state',['../class_m_d___key_switch.html#a56a689cb4a9c5bd7cdfeaddfcf109983',1,'MD_KeySwitch']]],
  ['_5ftimeactive',['_timeActive',['../class_m_d___key_switch.html#a15cfc6a0e027dff3f7c271b68d9bae94',1,'MD_KeySwitch']]],
  ['_5ftimedebounce',['_timeDebounce',['../class_m_d___key_switch.html#a86b2a576db6ba43a08a7a43e4827e6a1',1,'MD_KeySwitch']]],
  ['_5ftimedoublepress',['_timeDoublePress',['../class_m_d___key_switch.html#af445414de0645802cdc56c685d826a5d',1,'MD_KeySwitch']]],
  ['_5ftimelongpress',['_timeLongPress',['../class_m_d___key_switch.html#a7301b7989214cb4b30b5942019e9e2fe',1,'MD_KeySwitch']]],
  ['_5ftimerepeat',['_timeRepeat',['../class_m_d___key_switch.html#a624e37b712e5225d61c11c9a77182247',1,'MD_KeySwitch']]]
];

var searchData=
[
  ['key_5factive_5fstate',['KEY_ACTIVE_STATE',['../_m_d___key_switch_8h.html#a31b7db8ca6c72f2c2d1f35676ed7bf1c',1,'MD_KeySwitch.h']]],
  ['key_5fdebounce_5ftime',['KEY_DEBOUNCE_TIME',['../_m_d___key_switch_8h.html#a96040ac84b114c016c2fe3d517573140',1,'MD_KeySwitch.h']]],
  ['key_5fdpress_5ftime',['KEY_DPRESS_TIME',['../_m_d___key_switch_8h.html#aae76c0b46684910532977ccf29720536',1,'MD_KeySwitch.h']]],
  ['key_5flongpress_5ftime',['KEY_LONGPRESS_TIME',['../_m_d___key_switch_8h.html#ad04c46920a8921db4b689830ae664082',1,'MD_KeySwitch.h']]],
  ['key_5frepeat_5ftime',['KEY_REPEAT_TIME',['../_m_d___key_switch_8h.html#a27b2004a2239fff75146367890c36b6d',1,'MD_KeySwitch.h']]],
  ['keyresult_5ft',['keyResult_t',['../class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74a',1,'MD_KeySwitch']]],
  ['ks_5fdpress',['KS_DPRESS',['../class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa506572ca2664ccfd0fabd24e5e6348a5',1,'MD_KeySwitch']]],
  ['ks_5flongpress',['KS_LONGPRESS',['../class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa94293b5a79ec364f9ec5813ee57fb733',1,'MD_KeySwitch']]],
  ['ks_5fnull',['KS_NULL',['../class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa74d054189ce180aaa6e0200de8adc3e4',1,'MD_KeySwitch']]],
  ['ks_5fpress',['KS_PRESS',['../class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aae082ecde5fbf3366aa0107b6526a2530',1,'MD_KeySwitch']]],
  ['ks_5frptpress',['KS_RPTPRESS',['../class_m_d___key_switch.html#aaea71caba538c537c60c377616e2a74aa4b06e20a12208b175ac34a59982d4292',1,'MD_KeySwitch']]]
];

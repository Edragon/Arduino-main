Docs
====

Docs are available:

* Locally at [index.md](index.md)
* Online at http://marvinroger.github.io/homie-esp8266/

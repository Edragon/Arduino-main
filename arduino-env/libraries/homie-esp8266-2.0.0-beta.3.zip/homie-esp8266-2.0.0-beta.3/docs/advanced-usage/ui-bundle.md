The Homie for ESP8266 configuration AP implements a captive portal. When connecting to it, you will be prompted to connect, and your Web browser will open. By default, it will show an empty page with a text saying to install an `ui_bundle.gz` file.

Indeed, you can serve the [configuration UI](http://marvinroger.github.io/homie-esp8266/configurators/v2/) directly from your ESP8266. See [the data/homie folder](https://github.com/marvinroger/homie-esp8266/tree/develop/data/homie).

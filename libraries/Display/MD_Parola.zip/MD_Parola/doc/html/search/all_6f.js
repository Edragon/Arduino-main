var searchData=
[
  ['opening',['OPENING',['../class_m_d___parola.html#a6da9f7bb6b707465570196b6474d23fba31f6b9df9ec58784aa87ceb4a4b9b47a',1,'MD_Parola']]],
  ['opening_5fcursor',['OPENING_CURSOR',['../class_m_d___parola.html#a6da9f7bb6b707465570196b6474d23fba302d2440e3bf5d530dd8dd99e6d0620b',1,'MD_Parola']]]
];

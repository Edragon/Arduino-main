var searchData=
[
  ['parola_20hardware',['Parola Hardware',['../page_hardware.html',1,'index']]],
  ['parola_20software',['Parola Software',['../page_software.html',1,'index']]]
];

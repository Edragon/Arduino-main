var searchData=
[
  ['parola_20library',['Parola Library',['../pageSoftware.html',1,'index']]]
];

var searchData=
[
  ['texteffect_5ft',['textEffect_t',['../class_m_d___parola.html#a6da9f7bb6b707465570196b6474d23fb',1,'MD_Parola']]],
  ['textposition_5ft',['textPosition_t',['../class_m_d___parola.html#ad79b4f36f9dbba875c4fd3d10e9c144c',1,'MD_Parola']]]
];

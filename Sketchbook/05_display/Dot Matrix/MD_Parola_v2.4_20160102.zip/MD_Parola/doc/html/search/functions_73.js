var searchData=
[
  ['setcharspacing',['setCharSpacing',['../class_m_d___parola.html#ad7ff7418d5b57162353f5fc5334a1112',1,'MD_Parola']]],
  ['setintensity',['setIntensity',['../class_m_d___parola.html#aa869921483a67899f9d06d84f5e537b4',1,'MD_Parola']]],
  ['setinvert',['setInvert',['../class_m_d___parola.html#a1d555db081a7766f3e7e79b8cc228794',1,'MD_Parola']]],
  ['setpause',['setPause',['../class_m_d___parola.html#a535d4ba642406b02c26b6218e020c313',1,'MD_Parola']]],
  ['setspeed',['setSpeed',['../class_m_d___parola.html#a148064778dfb85eb1fd73fe415fc1126',1,'MD_Parola']]],
  ['settextalignment',['setTextAlignment',['../class_m_d___parola.html#a6eb132905e5df99067e9716fd922d9ed',1,'MD_Parola']]],
  ['settextbuffer',['setTextBuffer',['../class_m_d___parola.html#a1b54fb1c05c976007031433439324739',1,'MD_Parola']]],
  ['settexteffect',['setTextEffect',['../class_m_d___parola.html#af5c38fd43dbbb4169d5241ea17aa34bb',1,'MD_Parola']]]
];
